import thirdai._thirdai.deployment
from thirdai._thirdai.deployment import *

__all__ = []
__all__.extend(dir(thirdai._thirdai.deployment))
