from thirdai._deps.ColBERT.colbertmodeling.tokenization.query_tokenization import *
from thirdai._deps.ColBERT.colbertmodeling.tokenization.doc_tokenization import *
